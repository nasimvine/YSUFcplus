const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const defaultCode=`#include <iostream>
using namespace std;

int main() {
    cout << "Салом, Юсуф!" << endl;
    return 0;
}`;

let state=JSON.parse(localStorage.getItem("yusufCodeState")||"null")||{
 project:"Лоиҳаи ман",
 files:[{name:"main.cpp",type:"file",content:defaultCode},{name:"src",type:"folder",open:true},{name:"README.md",type:"file",content:"# YUSUF CODE\\nЛоиҳаи C++"}],
 current:"main.cpp", theme:"dark", input:""
};
const save=()=>{localStorage.setItem("yusufCodeState",JSON.stringify(state));$("#status").textContent="Захира шуд";};
const file=()=>state.files.find(x=>x.name===state.current);
const renderTree=()=>{
 $("#projectTitle").textContent=state.project;
 $("#fileTree").innerHTML=state.files.map((f,i)=>f.type==="folder"
 ? `<div class="tree-item folder" data-i="${i}">📁 <span>${esc(f.name)}</span><span class="dots">⋯</span></div>`
 : `<div class="tree-item ${f.name===state.current?"active":""}" data-i="${i}">📄 <span>${esc(f.name)}</span><span class="dots">⋯</span></div>`).join("");
 $$("#fileTree .tree-item").forEach(el=>el.onclick=()=>{let f=state.files[+el.dataset.i]; if(f.type==="file"){state.current=f.name;loadFile();}});
};
const esc=s=>s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
function loadFile(){let f=file(); if(!f)return;$("#currentFile").textContent=f.name;$("#code").value=f.content||"";syncEditor();renderTree();analyze();}
function syncEditor(){let lines=$("#code").value.split("\n").length;$("#lineNumbers").textContent=Array.from({length:lines},(_,i)=>i+1).join("\n");}
function updateFile(){let f=file();if(f){f.content=$("#code").value;save();}}
function analyze(){
 syncEditor(); let code=$("#code").value, problems=[];
 const checks=[
  {re:/\bcout\s*<<[^;\\n]*$/gm,msg:"Пас аз cout эҳтимолан ; фаромӯш шудааст."},
  {re:/\bint\s+main\s*\([^)]*\)\s*\{[^}]*$/s,msg:"Қавси } барои main эҳтимолан намерасад."},
 ];
 let brace=(code.match(/\{/g)||[]).length-(code.match(/\}/g)||[]).length;
 if(brace!==0) problems.push({line:Math.max(1,code.split("\n").length),msg:"Шумораи { ва } мувофиқ нест."});
 if(!/#include\s*<iostream>/.test(code)&&/\bcout\b|\bcin\b/.test(code)) problems.push({line:1,msg:"Барои cout/cin #include <iostream> илова кунед."});
 const lines=code.split("\n");
 lines.forEach((line,i)=>{if(/\bcout\b/.test(line)&&!/[;{}]\s*$/.test(line.trim())&&!/\/\//.test(line))problems.push({line:i+1,msg:"Дар охири фармон ; лозим аст."});});
 renderErrors(problems); return problems;
}
function renderErrors(problems){
 $("#problemCount").textContent=problems.length;
 $("#errorLayer").innerHTML=problems.map(p=>`<div class="error-line" style="top:${(p.line-1)*23}px"></div>`).join("");
 $("#problemsList").innerHTML=problems.length?problems.map(p=>`<div class="problem">🔴 <b>Сатри ${p.line}</b> — ${esc(p.msg)}</div>`).join(""):`<div class="empty">Ҳоло хато ёфт нашуд ✓</div>`;
}
function insertText(t){let ta=$("#code"),a=ta.selectionStart,b=ta.selectionEnd;let pair={"{":"{}","(":"()","[":"[]","<":"<>"}[t];let v=pair||t;ta.setRangeText(v,a,b,"end");if(pair)ta.selectionStart=ta.selectionEnd=a+1;updateFile();analyze();ta.focus();}
const words=["#include <iostream>","using namespace std;","int main()","cout <<","cin >>","endl","string","vector","for","while","if","else","return 0;","bool","double","long long","const","class","public:","private:","void","auto","std::vector","std::string"];
function autocomplete(){
 let ta=$("#code"), before=ta.value.slice(0,ta.selectionStart),m=before.match(/[A-Za-z_#][A-Za-z0-9_#]*$/);if(!m){$("#suggestions").style.display="none";return}
 let q=m[0].toLowerCase(), hits=words.filter(w=>w.toLowerCase().startsWith(q)&&w.toLowerCase()!==q).slice(0,7);
 let box=$("#suggestions");if(!hits.length){box.style.display="none";return}
 box.innerHTML=hits.map(x=>`<div class="suggestion">${esc(x)}</div>`).join("");box.style.display="block";
 let r=ta.getBoundingClientRect();box.style.left=(r.left+Math.min(160,Math.max(0,ta.selectionStart%70*7)))+"px";box.style.top=(r.top+80)+"px";
 $$(".suggestion").forEach(x=>x.onclick=()=>{let start=ta.selectionStart-m[0].length;ta.setRangeText(x.textContent,start,ta.selectionStart,"end");box.style.display="none";updateFile();analyze();ta.focus()});
}
function runCode(){
 updateFile();let problems=analyze();let code=$("#code").value,input=$("#programInput").value;
 switchPanel("output");
 if(problems.length){$("#output").textContent="❌ Код иҷро нашуд.\\n\\n"+problems.map(p=>`Сатри ${p.line}: ${p.msg}`).join("\\n");return}
 let out="▶ YUSUF CODE — иҷро шуд\\n\\n";
 let m=code.match(/cout\s*<<\s*(?:"([^"]*)"|'([^']*)')/);
 if(m) out+=(m[1]??m[2]).replace(/\\n/g,"\n");
 else if(/cout/.test(code)) out+="[Натиҷаи cout дар compiler-и воқеӣ ҳисоб мешавад]";
 else out+="Барнома бе output иҷро шуд.";
 if(input.trim())out+="\n\nInput:\n"+input;
 out+="\n\n✓ Бе хатои ошкор иҷро шуд";
 $("#output").textContent=out;
}
function switchPanel(name){$$(".panel-tabs button").forEach(b=>b.classList.toggle("active",b.dataset.panel===name));$$(".panel-view").forEach(v=>v.classList.remove("active"));$("#"+name+"Panel").classList.add("active");}
function modal(title,placeholder,cb){$("#modalTitle").textContent=title;$("#modalInput").placeholder=placeholder;$("#modalInput").value="";$("#modal").classList.add("show");$("#modalInput").focus();$("#modalOk").onclick=()=>{let v=$("#modalInput").value.trim();if(v){cb(v);$("#modal").classList.remove("show")}}}
$("#code").addEventListener("input",()=>{updateFile();analyze();autocomplete()});
$("#code").addEventListener("scroll",()=>{$("#lineNumbers").scrollTop=$("#code").scrollTop});
$("#code").addEventListener("keydown",e=>{if(e.key==="Tab"){e.preventDefault();insertText("    ")}});
$("#runBtn").onclick=runCode;$("#saveBtn").onclick=()=>{updateFile();$("#status").textContent="Захира шуд ✓"};
$("#undoBtn").onclick=()=>{document.execCommand("undo");updateFile();analyze()};$("#redoBtn").onclick=()=>{document.execCommand("redo");updateFile();analyze()};
$("#clearOutput").onclick=()=>$("#output").textContent="";
$("#themeBtn").onclick=()=>{document.body.classList.toggle("light");state.theme=document.body.classList.contains("light")?"light":"dark";save()};
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");$("#filesBtn").onclick=()=>$("#sidebar").classList.toggle("open");
$("#newFileBtn").onclick=()=>modal("Файли нав","main.cpp",(n)=>{if(!/\./.test(n))n+=".cpp";if(state.files.some(f=>f.name===n))return alert("Ин ном аллакай вуҷуд дорад.");state.files.push({name:n,type:"file",content:""});state.current=n;renderTree();loadFile()});
$("#newFolderBtn").onclick=()=>modal("Папкаи нав","src",(n)=>{state.files.push({name:n,type:"folder",open:true});renderTree();save()});
$("#newProjectBtn").onclick=()=>modal("Номи лоиҳа","Лоиҳаи ман",(n)=>{state.project=n;save();renderTree()});
$("#importBtn").onclick=()=>$("#fileInput").click();
$("#fileInput").onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{state.files.push({name:f.name,type:"file",content:r.result});state.current=f.name;renderTree();loadFile();save()};r.readAsText(f)};
$$(".panel-tabs button").forEach(b=>b.onclick=()=>switchPanel(b.dataset.panel));
$$(".mobile-keyboard button").forEach(b=>b.onclick=()=>insertText(b.dataset.insert));
$$(".bottom-nav button").forEach(b=>b.onclick=()=>{let n=b.dataset.nav;if(n==="files")$("#sidebar").classList.toggle("open");if(n==="run")runCode();if(n==="editor")$("#code").focus();if(n==="practice")alert("🏆 Қисми машқҳо дар версияи навбатӣ васеъ мешавад.");if(n==="settings")alert("⚙️ Танзимот: мавзӯъ бо тугмаи ◐ иваз мешавад.")});
$("#modalClose").onclick=$("#modalCancel").onclick=()=>$("#modal").classList.remove("show");
document.body.classList.toggle("light",state.theme==="light");$("#programInput").value=state.input||"";renderTree();loadFile();
window.addEventListener("beforeunload",updateFile);
