# YUSUF CODE 🇹🇯

**YUSUF CODE** — муҳити мобилии навиштан ва омӯзиши C++ бо интерфейси тоҷикӣ.

## Оғоз
Файлҳоро дар GitHub upload кунед ва `index.html`-ро кушоед. Барои GitHub Pages:
1. Repository созед.
2. Ҳамаи файлҳоро upload кунед.
3. Settings → Pages → Deploy from branch → `main` / root.
4. Суроғаи Pages-ро кушоед.

## Имкониятҳои версия
- Mobile-first UI
- C++ editor
- Line numbers
- Autocomplete
- Syntax-friendly editing
- Error highlighting-и базавӣ
- Project/file/folder manager
- LocalStorage
- Output/Input panel
- Mobile C++ keyboard
- Dark/Light mode
- Интерфейси пурраи тоҷикӣ

## Муҳим
Ин версия **frontend-only** аст. Тугмаи Run барои demo/output ва санҷиши базавии код кор мекунад, аммо compiler-и воқеии C++-ро дар браузер бе WebAssembly ё backend таъмин намекунад.

Барои compiler-и воқеӣ марҳилаи баъдӣ бояд `WASI/WebAssembly` ё backend-и sandboxed compiler илова кунад. Барои production бояд execution дар sandbox бошад ва timeout/resource limits дошта бошад.

**Муаллиф: Юсуф 🇹🇯**
